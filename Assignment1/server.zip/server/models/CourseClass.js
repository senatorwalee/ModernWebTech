//creating a course class 
class Course {
    constructor(id, name, department, isOpen) {
        this.id = id;               
        this.name = name;           
        this.department = department; 
        this.isOpen = isOpen;       
        
    }
}

export default Course